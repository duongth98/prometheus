# Hình ảnh
Tổng hợp hình ảnh
